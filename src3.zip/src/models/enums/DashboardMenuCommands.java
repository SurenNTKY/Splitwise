package models.enums;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum DashboardMenuCommands {
    CreateGroup("create-group\\s+-n\\s+(?<name>.+?)\\s+-t\\s+(?<type>\\S+)"),
    ShowMyGroups("show my groups"),
    AddUserToGroup("add-user\\s+-u\\s+(?<username>\\S+)\\s+-e\\s+(?<email>\\S+)\\s+-g\\s+(?<groupId>\\d+)"),
    AddExpense("add-expense\\s+-g\\s+(?<groupId>\\d+)\\s+-s\\s+(?<shareType>equally|unequally)\\s+-t\\s+(?<totalExpense>\\d+)(?:\\D+)?\\s+-n\\s+(?<numberOfUsers>\\d+)(?:\\s+-l\\s+(?<lines>.+))?"),
    ShowBalance("show balance\\s+-u\\s+(?<username>\\S+)"),
    SettleUp("settle-up\\s+-u\\s+(?<username>\\S+)\\s+-m\\s+(?<inputMoney>\\d+)"),
    GoToProfileMenu("go to profile menu"),
    Logout("logout"),
    Exit("exit");

    private final String pattern;

    DashboardMenuCommands(String pattern) {
        this.pattern = pattern;
    }

    public Matcher getMatcher(String input) {
        Matcher matcher = Pattern.compile(this.pattern).matcher(input);
        if (matcher.matches()) {
            return matcher;
        }
        return null;
    }
}
